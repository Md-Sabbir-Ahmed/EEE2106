/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:06
*/
#include<iostream>
using namespace std;
int main()
{

    cout << "   *   \n";
    cout << "  * *  \n";
    cout << " *   * \n";
    cout << "*******\n";
    cout << "*     *\n";
    cout << "*     *\n";
    cout << "*     *\n";


    return 0 ;
}
