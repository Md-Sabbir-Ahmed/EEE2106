/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:05
*/
#include<iostream>
using namespace std;
int main()
{
/*

    cout << "             **********             ***             *             *         \n";
    cout << "             *        *           *     *          ***           * *        \n";
    cout << "             *        *          *       *        *****         *   *       \n";
    cout << "             *        *          *       *          *          *     *      \n";
    cout << "             *        *          *       *          *         *       *     \n";
    cout << "             *        *          *       *          *          *     *      \n";
    cout << "             *        *          *       *          *           *   *       \n";
    cout << "             *        *           *     *           *            * *        \n";
    cout << "             **********             ***             *             *         \n";
*/

    cout<<"             **********             ***             *             *         \n             *        *           *     *          ***           * *        \n             *        *          *       *        *****         *   *       \n             *        *          *       *          *          *     *      \n             *        *          *       *          *         *       *     \n             *        *          *       *          *          *     *      \n             *        *          *       *          *           *   *       \n             *        *           *     *           *            * *        \n             **********             ***             *             *         \n";
    return 0 ;
}

