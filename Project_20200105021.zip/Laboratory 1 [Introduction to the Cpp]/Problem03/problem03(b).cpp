/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:03(b)
*/

#include<iostream>
using namespace std;
int main()
{

    cout<<"\tRED, \n\tGREEN , \n\tBLUE , \n\tBLACK , \n\tWHITE , \n\tORANGE";
    return 0 ;
}


