/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:03(c)
*/
#include<iostream>
using namespace std;
int main()
{

     cout<<"\tPURPLE, \tGREEN , \n\tBLACK , \tBLUE , \n\tWHITE , \tRED";
    return 0 ;
}


