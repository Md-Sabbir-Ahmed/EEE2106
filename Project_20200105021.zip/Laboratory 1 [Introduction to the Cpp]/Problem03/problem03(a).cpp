/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:03(a)
*/


#include<iostream>
using namespace std;
int main()
{

    cout<<"RED , GREEN , BLUE , BLACK , WHITE , ORANGE";
    return 0 ;
}

