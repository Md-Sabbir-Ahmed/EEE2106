/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:02
*/

//WRONG CODE:
/*
#include<iostream.h>
int main()
{

    cout<<"Patri";
    cout<<"ot "<<"G";
    cout<<"a"<<"m"<<"e"<<"\n";
    cout<<"\t Written" << " ";
    cout<<"B"<<"y"<<"\n";
    cout<<"\t\t Tom"<<" "<<"C";
    cout<<"lancy\n\n\n";
    return 0 ;
}
*/

//CORRECT CODE:
#include<iostream> //  wrong header file name in previous code
using namespace std; //using namespace std not mentioned in previous code
int main()
{

    cout << "Patri";
    cout << "ot "<<"G";
    cout << "a"<<"m"<<"e"<<"\n";
    cout << "\t Written" << " ";
    cout << "B"<<"y"<<"\n";
    cout << "\t\t Tom"<<" "<<"C";
    cout << "lancy\n\n\n";
    return 0 ;
}


