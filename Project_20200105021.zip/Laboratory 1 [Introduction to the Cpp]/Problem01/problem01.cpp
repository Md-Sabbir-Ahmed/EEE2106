/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:01
PROBLEM:01
*/

//WRONG CODE:
/*
#include<iostream>
using namespace std;
int main()
{

    "Hello , World!":
    cout<<"Hello , World!\n"
    return 0 ;
}
*/

//CORRECT CODE:
#include<iostream>
using namespace std;
int main()
{

    cout<<"Hello , World!"; // cout<< missing in previous code
    cout<<"Hello , World!\n"; // semicolon missing in previous code
    return 0 ;
}

