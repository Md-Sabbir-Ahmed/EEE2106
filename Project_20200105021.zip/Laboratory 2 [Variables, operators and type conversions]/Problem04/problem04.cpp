/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:02
PROBLEM:04
*/
#include<iostream>
using namespace std;
int main()
{

    float c,f;
    cout<<"Enter Celsius value: ";
    cin>>c;
    f=(9*c/5)+32;
    cout<<"Fahrenheit = "<<f<<endl;

    return 0 ;
}


