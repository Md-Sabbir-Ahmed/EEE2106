/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:02
PROBLEM:03
*/
#include<iostream>
using namespace std;
int main()
{

    float cm,in;
    cout<<"Enter the value: ";
    cin>>cm;
    in=cm*0.393;
    cout<<cm <<" Centimeter = "<<in<<" Inches";
    return 0 ;
}


