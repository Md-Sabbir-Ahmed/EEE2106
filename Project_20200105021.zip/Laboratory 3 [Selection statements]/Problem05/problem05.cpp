/*
NAME: MD. SABBIR AHMED
ID:20200105021
SECTION:A
----------------------
CHAPTER:03
PROBLEM:05
*/
#include<iostream>
using namespace std;
int main()
{
    char c;
    cout<<"Enter your Letter: ";
    cin>>c;
    switch(c)
    {
    case 'a':
        cout<<"Vowel";
        break;
    case 'e':
        cout<<"Vowel";
        break;
    case 'i':
        cout<<"Vowel";
        break;
    case 'o':
        cout<<"Vowel";
        break;
    case 'u':
        cout<<"Vowel";
        break;
    default:
        cout<<"Consonant";
        break;
    }
    return 0 ;
}

